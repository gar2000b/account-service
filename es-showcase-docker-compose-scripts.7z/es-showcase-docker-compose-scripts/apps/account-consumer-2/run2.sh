java -jar account-consumer-2-0.0.1-SNAPSHOT.jar --server.port=9096 > log2.txt
