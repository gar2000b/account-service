(cd /home/azureuser/apps/account-consumer-2 && screen -d -m -S account-consumer-2-1 ./run1.sh)
(cd /home/azureuser/apps/account-consumer-2 && screen -d -m -S account-consumer-2-2 ./run2.sh)
(cd /home/azureuser/apps/account-consumer-2 && screen -d -m -S account-consumer-2-3 ./run3.sh)
