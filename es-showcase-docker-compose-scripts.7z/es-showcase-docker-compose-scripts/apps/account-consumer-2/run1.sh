java -jar account-consumer-2-0.0.1-SNAPSHOT.jar --standup.new.service=false --server.port=9092 > log1.txt
