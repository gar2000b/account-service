(cd /home/azureuser/apps/account-consumer-3 && screen -d -m -S account-consumer-3-1 ./run1.sh)
(cd /home/azureuser/apps/account-consumer-3 && screen -d -m -S account-consumer-3-2 ./run2.sh)
(cd /home/azureuser/apps/account-consumer-3 && screen -d -m -S account-consumer-3-3 ./run3.sh)
