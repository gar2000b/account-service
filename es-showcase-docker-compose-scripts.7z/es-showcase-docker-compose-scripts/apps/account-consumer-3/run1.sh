java -jar account-consumer-3-0.0.1-SNAPSHOT.jar --server.port=9093 --standup.new.service=false > log1.txt
