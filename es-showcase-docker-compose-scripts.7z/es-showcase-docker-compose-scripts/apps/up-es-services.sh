#!/bin/bash
/home/azureuser/apps/account-consumer-1/account-consumer-1.sh
/home/azureuser/apps/account-consumer-2/account-consumer-2.sh
/home/azureuser/apps/account-consumer-3/account-consumer-3.sh
/home/azureuser/apps/account-service/account-service.sh
#./snapshot-service/snapshot-service.sh
