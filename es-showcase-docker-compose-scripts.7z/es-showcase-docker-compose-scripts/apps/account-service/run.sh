java -jar account-service-0.0.1-SNAPSHOT.jar > account-service-log.txt
