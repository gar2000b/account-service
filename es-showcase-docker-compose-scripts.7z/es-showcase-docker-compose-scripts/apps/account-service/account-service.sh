#!/bin/bash
(cd /home/azureuser/apps/account-service && screen -d -m -S account-service ./run.sh)
