#!/bin/bash
(cd /home/azureuser/apps/snapshot-service && screen -d -m -S snapshot-service ./run.sh)
