java -jar snapshot-service-0.0.1-SNAPSHOT.jar
