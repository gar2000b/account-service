#!/bin/bash
screen -ls | grep 'account-consumer' | awk '{print $1}' | xargs -I % -t screen -X -S % quit
screen -ls | grep 'account-service' | awk '{print $1}' | xargs -I % -t screen -X -S % quit
screen -ls | grep 'snapshot-service' | awk '{print $1}' | xargs -I % -t screen -X -S % quit

