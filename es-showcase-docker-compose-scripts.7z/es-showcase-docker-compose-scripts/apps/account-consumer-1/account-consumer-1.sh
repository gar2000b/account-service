#!/bin/bash
(cd /home/azureuser/apps/account-consumer-1 && screen -d -m -S account-consumer-1-1 ./run1.sh)
(cd /home/azureuser/apps/account-consumer-1 && screen -d -m -S account-consumer-1-2 ./run2.sh)
(cd /home/azureuser/apps/account-consumer-1 && screen -d -m -S account-consumer-1-3 ./run3.sh)

