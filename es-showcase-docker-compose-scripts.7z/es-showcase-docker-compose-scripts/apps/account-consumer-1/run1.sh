java -jar account-consumer-1-0.0.1-SNAPSHOT.jar --standup.new.service=false --server.port=9091 > log1.txt
