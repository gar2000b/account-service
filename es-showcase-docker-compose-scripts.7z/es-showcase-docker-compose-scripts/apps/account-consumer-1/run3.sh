java -jar account-consumer-1-0.0.1-SNAPSHOT.jar --server.port=9095 > log3.txt
